package com.example.demo.Controller;
import com.example.demo.Repository.*;
import com.example.demo.*;
import com.example.demo.Entity.Transaction_Record;
import com.example.demo.Entity.User_Info;
import com.example.demo.Entity.Wallet;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Controller {
	@Autowired
	private UserDetailRepo  userDetailRepositoty;
	@Autowired
	private WalletRepo walletRepositoty;
	@Autowired
	private TransactionRepo transactionRepositoty;
	
	
	@PostMapping("/createNewUser")
	public User_Info addUser(@RequestBody User_Info user)
	{
		Wallet w1 = user.getWallet();
		walletRepositoty.save(w1);
		userDetailRepositoty.save(user);
		return user;
		
	}
	
	@GetMapping("/getUser/{Mobile_Number}")
	public String getUser(@PathVariable("Mobile_Number") BigInteger  Mobile_Number ) {
		
		List<User_Info> user = userDetailRepositoty.findAll();
		
		for (User_Info user_Details : user) {
			if ( Mobile_Number == user_Details.getMobile_Number())
			{
				String req_user = user_Details.getWallet().getUpi_ID();
				 return req_user;
			}
			
		}
		
		return "Upi not registered on this mobile Number";
	}
	
	@PutMapping("/updateUser")
	public User_Info updateUser(@RequestBody User_Info user)
	{
		Wallet w1 = user.getWallet();
		walletRepositoty.save(w1);
		userDetailRepositoty.save(user);
		return user;
		
	}
	
	@PutMapping("/fundTranfer")
	public String transferFund ( @RequestBody Transaction_Record transaction) {
		
		Transaction_Record debit =  null;
		Transaction_Record credit = null;
		
		String id[] = transaction.getT_id().split("@");
		
		String debit_upi_id = id[0];
		String credit_upi_id = id[2];
		
		
		transactionRepositoty.getOne(transaction.getT_id());
		
	
		

		
		
		return "fund transfer successful";
	}

}
