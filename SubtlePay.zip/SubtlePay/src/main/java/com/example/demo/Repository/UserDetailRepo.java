package com.example.demo.Repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.Entity.User_Info;

public interface UserDetailRepo extends JpaRepository<User_Info, Integer> {
	 
	@Query( value="select * from User_Details where Mobile_Number = ?1", nativeQuery = true)
	User_Info findByMobileNumber(long MobileNumber);

}
