package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Transaction_Record;

public interface TransactionRepo extends JpaRepository<Transaction_Record, String> {

}
